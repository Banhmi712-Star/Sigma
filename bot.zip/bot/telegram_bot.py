# telegram_bot.py
import telebot
import threading
import time
from pathlib import Path
import json
import os

# Ensure all necessary packages are installed before importing
REQUIRED_PACKAGES = [
    "pyTelegramBotAPI", "requests", "rich", "colorama", "sqlalchemy",
    "pandas", "numpy", "xgboost", "lightgbm", "scikit-learn", "optuna"
]
for pkg in REQUIRED_PACKAGES:
    try:
        __import__(pkg)
    except ImportError:
        import subprocess
        print(f"Package '{pkg}' not found. Installing...")
        subprocess.check_call(["pip", "install", pkg])
        print(f"Package '{pkg}' installed.")

# Now import modules
import config
from utils import console, build_endpoints_and_headers, send_long_message, requestsGET
from game_logic import (
    session_init, start_betting, stop_betting, get_current_session_info,
    user_sessions, telegram_bot_instance as game_logic_bot_instance_ref
)
from data_manager import (
    get_telegram_user, create_or_update_telegram_user, get_all_telegram_users,
    get_user_game_config, update_user_game_config, get_session_stats,
    set_user_bot_running_status
)

# --- Initialize Telegram Bot ---
bot = telebot.TeleBot(config.TELEGRAM_BOT_TOKEN)
# Pass the bot instance to game_logic for sending messages from threads
game_logic_bot_instance_ref = bot

# --- Helper Functions ---
def is_admin(message) -> bool:
    """Checks if the sender of the message is an admin."""
    return str(message.chat.id) in config.ADMIN_CHAT_IDS

def get_user_display_name(user_obj) -> str:
    """Returns a formatted display name for a Telegram user."""
    if user_obj.username:
        return f"@{user_obj.username}"
    if user_obj.first_name and user_obj.last_name:
        return f"{user_obj.first_name} {user_obj.last_name}"
    if user_obj.first_name:
        return user_obj.first_name
    return "Người dùng ẩn danh"

# --- Telegram Bot Commands ---

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    chat_id = str(message.chat.id)
    user_info = message.from_user
    
    # Create or update user in DB
    is_admin_user = is_admin(message)
    create_or_update_telegram_user(
        chat_id,
        user_info.username,
        user_info.first_name,
        user_info.last_name,
        is_admin=is_admin_user
    )

    help_text = """
Chào mừng đến với Xworld EINSTEIN Bot!
Đây là một bot đặt cược tự động thông minh.

*Lệnh cơ bản:*
/config - Cấu hình Link Game và loại tiền của bạn.
/settings - Xem các cài đặt hiện tại của bạn (chốt lời, cược min/max, v.v.).
/set <key> <value> - Thay đổi một cài đặt cụ thể (ví dụ: `/set stake_min 40`).
/status - Xem trạng thái hoạt động và PnL của bot.
/start_bet - Bắt đầu chế độ đặt cược tự động.
/stop_bet - Dừng chế độ đặt cược.
"""
    if is_admin_user:
        help_text += """
*Lệnh Admin:*
/admin_users - Xem danh sách tất cả người dùng bot.
/admin_message <chat_id> <tin_nhan> - Gửi tin nhắn riêng đến một người dùng.
/admin_broadcast <tin_nhan> - Gửi tin nhắn đến tất cả người dùng bot.
"""
    
    send_long_message(chat_id, help_text, parse_mode='Markdown')

@bot.message_handler(commands=['config'])
def handle_config(message):
    chat_id = str(message.chat.id)
    
    user_game_config = get_user_game_config(chat_id)
    if not user_game_config:
        # Initialize with default values if no config exists
        user_game_config = {
            "url_game": config.DEFAULT_URL_GAME,
            "bet_type": config.DEFAULT_BET_TYPE,
            "stake_min": config.DEFAULT_STAKE_MIN,
            "stake_max": config.DEFAULT_STAKE_MAX,
            "take_profit": config.DEFAULT_TAKE_PROFIT,
            "stop_loss": config.DEFAULT_STOP_LOSS,
            "kelly_fraction": config.DEFAULT_KELLY_FRACTION,
            "ENTROPY_SKIP": config.ENTROPY_SKIP,
            "ENTROPY_HYSTERESIS_K": config.ENTROPY_HYSTERESIS_K,
            "EMA_ALPHA": config.EMA_ALPHA,
            "SKIP_MODE": config.SKIP_MODE,
            "TEACHER_MODE": config.TEACHER_MODE,
        }
        update_user_game_config(chat_id, user_game_config)

    # Check if URL game is set
    if not user_game_config.get("url_game"):
        msg = bot.reply_to(message, "🔗 Vui lòng gửi Link Game của bạn (chứa userId và secretKey):")
        bot.register_next_step_handler(msg, process_game_url_step, chat_id)
        return

    # Check if bet type is set
    if not user_game_config.get("bet_type"):
        msg = bot.reply_to(message, "💱 Vui lòng gửi Loại tiền (BUILD/USDT/WORLD):")
        bot.register_next_step_handler(msg, process_bet_type_step, chat_id)
        return

    # Display current configuration
    config_display = f"""
✅ Cấu hình hiện tại của bạn:
🔗 Link Game: `{user_game_config['url_game']}`
💱 Loại tiền: `{user_game_config['bet_type']}`
🔢 Cược min: `{user_game_config['stake_min']}`
🔢 Cược max: `{user_game_config['stake_max']}`
🎯 Chốt lời: `{user_game_config['take_profit']}`
🛑 Cắt lỗ: `{user_game_config['stop_loss']}`
💰 Kelly Fraction: `{user_game_config['kelly_fraction']}`
"""
    send_long_message(chat_id, config_display, parse_mode='Markdown')

def process_game_url_step(message, chat_id: str):
    url_game = message.text.strip()
    try:
        # Validate URL by attempting to build endpoints
        temp_config = {"url_game": url_game, "bet_type": "BUILD"} # bet_type is placeholder for validation
        build_endpoints_and_headers(temp_config)
        
        update_user_game_config(chat_id, {"url_game": url_game})
        msg = bot.reply_to(message, "💱 Vui lòng gửi Loại tiền (BUILD/USDT/WORLD):")
        bot.register_next_step_handler(msg, process_bet_type_step, chat_id)
    except ValueError as e:
        bot.reply_to(message, f"❌ Link Game không hợp lệ: {e}. Vui lòng thử lại.")
        msg = bot.reply_to(message, "🔗 Vui lòng gửi Link Game của bạn:")
        bot.register_next_step_handler(msg, process_game_url_step, chat_id)
    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi khi lưu cấu hình: {e}")

def process_bet_type_step(message, chat_id: str):
    bet_type = message.text.strip().upper()
    if bet_type in ["BUILD", "USDT", "WORLD"]:
        update_user_game_config(chat_id, {"bet_type": bet_type})
        bot.reply_to(message, f"✅ Cấu hình đã được lưu. Loại tiền: `{bet_type}`", parse_mode='Markdown')
    else:
        bot.reply_to(message, "❌ Loại tiền không hợp lệ. Vui lòng nhập BUILD, USDT hoặc WORLD.")
        msg = bot.reply_to(message, "💱 Vui lòng gửi Loại tiền (BUILD/USDT/WORLD):")
        bot.register_next_step_handler(msg, process_bet_type_step, chat_id)

@bot.message_handler(commands=['start_bet'])
def handle_start_bet(message):
    chat_id = str(message.chat.id)
    if not is_admin(message): # Only admins can start the bot for now
        bot.reply_to(message, "Bạn không có quyền sử dụng bot này.")
        return
    
    user_game_config = get_user_game_config(chat_id)
    if not user_game_config or not user_game_config.get("url_game") or not user_game_config.get("bet_type"):
        bot.reply_to(message, "❌ Vui lòng cấu hình bot trước bằng lệnh /config.")
        return

    start_betting(chat_id)

@bot.message_handler(commands=['stop_bet'])
def handle_stop_bet(message):
    chat_id = str(message.chat.id)
    if not is_admin(message): # Only admins can stop the bot for now
        bot.reply_to(message, "Bạn không có quyền sử dụng bot này.")
        return
    
    stop_betting(chat_id)

@bot.message_handler(commands=['status'])
def handle_status(message):
    chat_id = str(message.chat.id)
    if not is_admin(message): # Only admins can view status for now
        bot.reply_to(message, "Bạn không có quyền sử dụng bot này.")
        return
    
    current_session_info = get_current_session_info(chat_id)
    
    # Update PnL and other stats from DB for accurate display
    db_stats = get_session_stats(telegram_chat_id=chat_id)
    current_session_info.update(db_stats)

    # Get user's game config for displaying stake_min/max and asset
    user_game_config = get_user_game_config(chat_id)
    if user_game_config:
        current_session_info["stake_min"] = user_game_config.get("stake_min", config.DEFAULT_STAKE_MIN)
        current_session_info["stake_max"] = user_game_config.get("stake_max", config.DEFAULT_STAKE_MAX)
        current_session_info["asset"] = user_game_config.get("bet_type", config.DEFAULT_BET_TYPE)
        current_session_info["kelly_fraction"] = user_game_config.get("kelly_fraction", config.DEFAULT_KELLY_FRACTION)

    # Format for Telegram
    elapsed = int(time.time() - (current_session_info["start_ts"] or time.time()))
    hh = elapsed // 3600; mm = (elapsed % 3600)//60; ss = elapsed % 60
    tl = f"{hh:02d}:{mm:02d}:{ss:02d}"
    pnl_text = f"{current_session_info['pnl_asset']:+.3f} {current_session_info['asset']}"
    stake_text = f"{current_session_info['stake_min']}–{current_session_info['stake_max']} {current_session_info['asset']}"

    status_msg = f"""
*📊 TRẠNG THÁI BOT*
Trạng thái: {'🟢 Đang chạy' if user_sessions.get(chat_id, {}).get('initialized', False) and user_sessions.get(chat_id, {}).get('start_ts') is not None else '🔴 Đã dừng'}
⏱️ Thời gian hoạt động: `{tl}`
🏆 Thắng: `{current_session_info['wins']}`
💥 Thua: `{current_session_info['losses']}`
🧯 Chuỗi thua: `{current_session_info['lose_streak']}`
💸 Tổng đã cược: `{current_session_info['total_staked']:.3f} {current_session_info['asset']}`
🪙 Cược min–max: `{stake_text}`
💰 Kelly Fraction: `{current_session_info['kelly_fraction']:.2f}`
📈 Lời/Lỗ (phiên): `{pnl_text}`
"""
    send_long_message(chat_id, status_msg, parse_mode='Markdown')

@bot.message_handler(commands=['settings'])
def handle_settings(message):
    chat_id = str(message.chat.id)
    if not is_admin(message): # Only admins can view settings for now
        bot.reply_to(message, "Bạn không có quyền sử dụng bot này.")
        return
    
    user_game_config = get_user_game_config(chat_id)
    if not user_game_config:
        bot.reply_to(message, "❌ Bạn chưa cấu hình bot. Vui lòng sử dụng lệnh /config.")
        return

    settings_text = "*⚙️ CÀI ĐẶT HIỆN TẠI CỦA BẠN:*\n"
    for key, value in user_game_config.items():
        settings_text += f"`{key}`: `{value}`\n"
    
    settings_text += "\nSử dụng `/set <key> <value>` để thay đổi."
    send_long_message(chat_id, settings_text, parse_mode='Markdown')

@bot.message_handler(commands=['set'])
def handle_set_setting(message):
    chat_id = str(message.chat.id)
    if not is_admin(message): # Only admins can change settings for now
        bot.reply_to(message, "Bạn không có quyền sử dụng bot này.")
        return
    
    args = message.text.split(maxsplit=2)
    if len(args) != 3:
        bot.reply_to(message, "❌ Cú pháp không hợp lệ. Sử dụng: `/set <key> <value>`")
        return
    
    key = args[1].lower() # Keys in user_game_config are lowercase
    value_str = args[2]

    user_game_config = get_user_game_config(chat_id)
    if not user_game_config:
        bot.reply_to(message, "❌ Bạn chưa cấu hình bot. Vui lòng sử dụng lệnh /config.")
        return

    try:
        # Determine type and convert value
        if key in ["stake_min", "stake_max", "entropy_hysteresis_k"]:
            value = int(value_str)
        elif key in ["take_profit", "stop_loss", "kelly_fraction", "entropy_skip", "ema_alpha"]:
            value = float(value_str)
        elif key == "skip_mode":
            value = value_str.lower()
            if value not in ["soft", "hard", "off"]:
                raise ValueError("Skip mode phải là 'soft', 'hard' hoặc 'off'.")
        elif key == "teacher_mode":
            value = value_str.lower() in ['true', '1', 'yes']
        elif key in ["url_game", "bet_type"]: # Allow changing game config directly
            value = value_str
            if key == "bet_type" and value.upper() not in ["BUILD", "USDT", "WORLD"]:
                raise ValueError("Loại tiền không hợp lệ. Vui lòng nhập BUILD, USDT hoặc WORLD.")
            if key == "url_game": # Validate URL if changed
                temp_config = {"url_game": value, "bet_type": user_game_config.get("bet_type", "BUILD")}
                build_endpoints_and_headers(temp_config) # Validate URL
        else:
            bot.reply_to(message, f"❌ Cài đặt `{key}` không tồn tại hoặc không thể thay đổi.")
            return
        
        # Update user's game config in DB
        update_user_game_config(chat_id, {key: value})
        # Update in-memory session if bot is running
        if chat_id in user_sessions:
            user_sessions[chat_id][key.upper()] = value # Update uppercase key in session

        bot.reply_to(message, f"✅ Đã cập nhật `{key}` thành `{value}`.")
    except ValueError as e:
        bot.reply_to(message, f"❌ Giá trị không hợp lệ cho `{key}`: {e}")
    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi khi cập nhật cài đặt: {e}")

# --- Admin Commands ---
@bot.message_handler(commands=['admin_users'])
def handle_admin_users(message):
    chat_id = str(message.chat.id)
    if not is_admin(message):
        bot.reply_to(message, "Bạn không có quyền sử dụng lệnh này.")
        return
    
    users = get_all_telegram_users()
    if not users:
        bot.reply_to(message, "Chưa có người dùng nào tương tác với bot.")
        return

    response_msg = "*Danh sách người dùng bot:*\n\n"
    for user in users:
        user_config = json.loads(user.game_config_json) if user.game_config_json else {}
        
        # Fetch wallet balance for each user
        wallet_balance = "N/A"
        if user_config.get("url_game") and user_config.get("bet_type"):
            try:
                # Need to rebuild headers for each user to fetch their wallet
                temp_user_id, temp_header_user, _, _ = build_endpoints_and_headers(user_config)
                w = requestsGET("https://user.3games.io/user/regist?is_cwallet=1&is_mission_setting=true&version=", temp_header_user).get("data", {}).get("cwallet", {})
                wallet_balance = w.get(f"ctoken_{user_config['bet_type'].lower()}", 0.0)
            except Exception as e:
                wallet_balance = f"Lỗi: {e}"
        
        response_msg += f"ID: `{user.chat_id}`\n" \
                        f"Tên: `{get_user_display_name(user)}`\n" \
                        f"Admin: `{user.is_admin}`\n" \
                        f"Link Game: `{user_config.get('url_game', 'Chưa cấu hình')}`\n" \
                        f"Loại tiền: `{user_config.get('bet_type', 'N/A')}`\n" \
                        f"Ví ({user_config.get('bet_type', 'N/A')}): `{wallet_balance}`\n" \
                        f"Trạng thái bot: {'🟢 Đang chạy' if user.is_bot_running else '🔴 Đã dừng'}\n" \
                        f"---\n"
    
    send_long_message(chat_id, response_msg, parse_mode='Markdown')

@bot.message_handler(commands=['admin_message'])
def handle_admin_message(message):
    chat_id = str(message.chat.id)
    if not is_admin(message):
        bot.reply_to(message, "Bạn không có quyền sử dụng lệnh này.")
        return
    
    args = message.text.split(maxsplit=2) # /admin_message <target_chat_id> <message>
    if len(args) < 3:
        bot.reply_to(message, "❌ Cú pháp không hợp lệ. Sử dụng: `/admin_message <chat_id> <tin_nhan>`")
        return
    
    target_chat_id = args[1]
    admin_message = args[2]

    try:
        send_long_message(target_chat_id, f"*Tin nhắn từ Admin:*\n{admin_message}", parse_mode='Markdown')
        bot.reply_to(message, f"✅ Đã gửi tin nhắn đến `{target_chat_id}`.")
    except Exception as e:
        bot.reply_to(message, f"❌ Lỗi khi gửi tin nhắn đến `{target_chat_id}`: {e}")

@bot.message_handler(commands=['admin_broadcast'])
def handle_admin_broadcast(message):
    chat_id = str(message.chat.id)
    if not is_admin(message):
        bot.reply_to(message, "Bạn không có quyền sử dụng lệnh này.")
        return
    
    args = message.text.split(maxsplit=1) # /admin_broadcast <message>
    if len(args) < 2:
        bot.reply_to(message, "❌ Cú pháp không hợp lệ. Sử dụng: `/admin_broadcast <tin_nhan>`")
        return
    
    broadcast_message = args[1]
    
    users = get_all_telegram_users()
    sent_count = 0
    for user in users:
        try:
            send_long_message(user.chat_id, f"*Thông báo từ Admin:*\n{broadcast_message}", parse_mode='Markdown')
            sent_count += 1
        except Exception as e:
            console.print(f"[red]Lỗi khi gửi broadcast đến {user.chat_id}: {e}[/red]")
    
    bot.reply_to(message, f"✅ Đã gửi broadcast đến {sent_count} người dùng.")

# --- Main Execution ---
if __name__ == "__main__":
    console.print("[bold green]Khởi tạo Xworld EINSTEIN Telegram Bot...[/bold green]")
    
    # Set the bot instance in game_logic
    game_logic_bot_instance_ref = bot

    console.print(f"[bold blue]Bot Telegram đang lắng nghe... (Admin Chat IDs: {config.ADMIN_CHAT_IDS})[/bold blue]")
    
    # Start polling for messages
    try:
        bot.polling(non_stop=True, interval=0) # interval=0 for immediate updates
    except Exception as e:
        console.print(f"[red]Error starting Telegram bot polling: {e}[/red]")
        console.print("[red]Please check your TELEGRAM_BOT_TOKEN and network connection.[/red]")