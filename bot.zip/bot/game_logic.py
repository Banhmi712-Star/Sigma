# game_logic.py
import time
import json
import math
import random
from collections import deque
from datetime import datetime
import threading

# Import from other modules
import config
from utils import (
    console, requestsGET, requestsPOST, normalize, entropy, clamp,
    ROOM_MAP, ROOM_IDS, build_endpoints_and_headers, dirichlet_mean, eb_shrinkage,
    recency_distribution, build_markov1, predict_markov1, build_markov2,
    predict_markov2, gap_hazard_distribution, gap_anti_streak_scores,
    scores_to_prob, log_loss, isotonic_regression_pav, apply_isotonic,
    temperature_calibrate, learn_weights_EG, find_best_temperature,
    thompson_sampling_dirichlet, build_components, change_point_alert
)
from data_manager import (
    save_game_record, get_historical_data, GameRecord, get_session_stats,
    get_telegram_user, create_or_update_telegram_user, get_user_game_config,
    update_user_game_config, set_user_bot_running_status
)
from prediction_model import train_prediction_model, predict_next_kill_probabilities, create_features, feature_names

# --- Global Session Template ---
# This template defines the structure of a user's session data.
# Actual values will be loaded from user_game_config and updated dynamically.
SESSION_TEMPLATE = {
    "initialized": False,
    "start_ts": None,
    "wins": 0,
    "losses": 0,
    "lose_streak": 0,
    "asset": "BUILD",
    "total_staked": 0.0,
    "pnl_asset": 0.0,
    # These will be populated from user_game_config
    "stake_min": None, "stake_max": None,
    "take_profit": None, "stop_loss": None,
    "kelly_fraction": None, # Adaptive Kelly will modify this
    "ENTROPY_SKIP": None, "ENTROPY_HYSTERESIS_K": None,
    "EMA_ALPHA": None, "SKIP_MODE": None, "TEACHER_MODE": None,
    "last_retrain_issue_count": 0 # For model retraining logic
}

# --- Global Bot State ---
telegram_bot_instance = None # Reference to the TeleBot instance for sending messages
running_bots = {} # {chat_id: True/False} - Tracks which user bots are active
user_sessions = {} # {chat_id: SESSION_TEMPLATE_copy} - Stores in-memory session data for each user

# --- User Session Management ---
def get_user_session(chat_id: str) -> dict:
    """Retrieves or initializes the in-memory session for a given user."""
    if chat_id not in user_sessions:
        user_sessions[chat_id] = SESSION_TEMPLATE.copy()
        user_sessions[chat_id]["start_ts"] = time.time() # Initialize start time
        
        # Load initial config from DB for this user
        user_game_config = get_user_game_config(chat_id)
        if user_game_config:
            user_sessions[chat_id].update({
                "stake_min": user_game_config.get("stake_min", config.DEFAULT_STAKE_MIN),
                "stake_max": user_game_config.get("stake_max", config.DEFAULT_STAKE_MAX),
                "take_profit": user_game_config.get("take_profit", config.DEFAULT_TAKE_PROFIT),
                "stop_loss": user_game_config.get("stop_loss", config.DEFAULT_STOP_LOSS),
                "kelly_fraction": user_game_config.get("kelly_fraction", config.DEFAULT_KELLY_FRACTION),
                "ENTROPY_SKIP": user_game_config.get("ENTROPY_SKIP", config.ENTROPY_SKIP),
                "ENTROPY_HYSTERESIS_K": user_game_config.get("ENTROPY_HYSTERESIS_K", config.ENTROPY_HYSTERESIS_K),
                "EMA_ALPHA": user_game_config.get("EMA_ALPHA", config.EMA_ALPHA),
                "SKIP_MODE": user_game_config.get("SKIP_MODE", config.SKIP_MODE),
                "TEACHER_MODE": user_game_config.get("TEACHER_MODE", config.TEACHER_MODE),
                "asset": user_game_config.get("bet_type", config.DEFAULT_BET_TYPE),
            })
    return user_sessions[chat_id]

def session_init(chat_id: str, asset: str = None):
    """Initializes or re-initializes a user's session, loading stats from DB."""
    user_session = get_user_session(chat_id)
    if not user_session["initialized"]:
        user_session["initialized"] = True
        user_session["start_ts"] = time.time()
        if asset: user_session["asset"] = asset
    
    # Load latest stats from DB for this user
    db_stats = get_session_stats(chat_id)
    user_session.update(db_stats)

def get_current_session_info(chat_id: str) -> dict:
    """Returns a copy of the current session info for a user."""
    user_session = get_user_session(chat_id)
    st = user_session.copy()
    st["elapsed_time"] = int(time.time() - (st["start_ts"] or time.time()))
    return st

# --- Wrapper Functions for Config Parameters ---
# These wrappers ensure that config parameters are fetched from the global config
# or user-specific config if available, providing a consistent interface.
def wilson_lower_bound_wrapper(k, n):
    return wilson_lower_bound(k, n, z=config.WILSON_Z)

def beta_lower_quantile_from_mean_n_wrapper(m, n_eff):
    return beta_lower_quantile_from_mean_n(m, n_eff, q=config.CONFORMAL_ALPHA)

def change_point_alert_wrapper(hist10):
    return change_point_alert(hist10, cp_llr_skip_z=config.CP_LLR_SKIP_Z)

def choose_room_wrapper(p_kill: dict, counts: dict, trust: dict | None = None):
    return choose_room(p_kill, counts, trust, wilson_z=config.WILSON_Z)

# --- Telegram Messaging ---
def send_telegram_message(chat_id: str, text: str, parse_mode: str = 'Markdown'):
    """Sends a message to a Telegram chat."""
    if telegram_bot_instance:
        try:
            telegram_bot_instance.send_message(chat_id, text, parse_mode=parse_mode)
        except Exception as e:
            console.print(f"[red]Error sending Telegram message to {chat_id}: {e}[/red]")

# --- Main Betting Logic ---
def bet_loop_core(chat_id: str):
    """
    The core betting loop for a single user. Runs in a separate thread.
    Manages game state, predictions, betting, and session updates.
    """
    global telegram_bot_instance, running_bots

    console.print(f"[bold blue][{chat_id}] Starting bet_loop_core...[/bold blue]")

    # --- Load User-Specific Configuration ---
    user_game_config = get_user_game_config(chat_id)
    if not user_game_config:
        send_telegram_message(chat_id, "❌ Không tìm thấy cấu hình game của bạn. Vui lòng sử dụng lệnh /config.")
        running_bots.pop(chat_id, None)
        set_user_bot_running_status(chat_id, False)
        console.print(f"[red][{chat_id}] No game config found. Stopping bot.[/red]")
        return

    try:
        user_id_game, header_user_game, header_room_game, api_endpoints_game = build_endpoints_and_headers(user_game_config)
        bet_asset_game = user_game_config["bet_type"]
    except ValueError as e:
        send_telegram_message(chat_id, f"❌ Cấu hình Link Game không hợp lệ: {e}. Vui lòng kiểm tra /config.")
        running_bots.pop(chat_id, None)
        set_user_bot_running_status(chat_id, False)
        console.print(f"[red][{chat_id}] Invalid game URL config. Stopping bot.[/red]")
        return
    except Exception as e:
        send_telegram_message(chat_id, f"❌ Lỗi khi khởi tạo API từ cấu hình của bạn: {e}. Vui lòng kiểm tra /config.")
        running_bots.pop(chat_id, None)
        set_user_bot_running_status(chat_id, False)
        console.print(f"[red][{chat_id}] Error building API endpoints. Stopping bot.[/red]")
        return

    # --- Initialize User Session ---
    user_session = get_user_session(chat_id)
    user_session.update({
        "stake_min": user_game_config.get("stake_min", config.DEFAULT_STAKE_MIN),
        "stake_max": user_game_config.get("stake_max", config.DEFAULT_STAKE_MAX),
        "take_profit": user_game_config.get("take_profit", config.DEFAULT_TAKE_PROFIT),
        "stop_loss": user_game_config.get("stop_loss", config.DEFAULT_STOP_LOSS),
        "kelly_fraction": user_game_config.get("kelly_fraction", config.DEFAULT_KELLY_FRACTION),
        "ENTROPY_SKIP": user_game_config.get("ENTROPY_SKIP", config.ENTROPY_SKIP),
        "ENTROPY_HYSTERESIS_K": user_game_config.get("ENTROPY_HYSTERESIS_K", config.ENTROPY_HYSTERESIS_K),
        "EMA_ALPHA": user_game_config.get("EMA_ALPHA", config.EMA_ALPHA),
        "SKIP_MODE": user_game_config.get("SKIP_MODE", config.SKIP_MODE),
        "TEACHER_MODE": user_game_config.get("TEACHER_MODE", config.TEACHER_MODE),
        "asset": bet_asset_game,
    })
    session_init(chat_id, asset=bet_asset_game)

    # --- Local Variables from User Session ---
    stake_min = user_session["stake_min"]
    stake_max = user_session["stake_max"]
    take_profit = user_session["take_profit"]
    stop_loss = user_session["stop_loss"]
    kelly_fraction = user_session["kelly_fraction"] # This will be adaptive
    entropy_skip = user_session["ENTROPY_SKIP"]
    entropy_hysteresis_k = user_session["ENTROPY_HYSTERESIS_K"]
    ema_alpha = user_session["EMA_ALPHA"]
    skip_mode = user_session["SKIP_MODE"]
    teacher_mode = user_session["TEACHER_MODE"]

    # --- Prediction & State Variables ---
    trust = {} # Trust scores for rooms
    picks_window = deque(maxlen=80) # History of successful picks (survived/killed)
    calib_pairs = deque(maxlen=120) # Pairs for isotonic regression calibration
    last_processed_issue = None
    last_ui_issue = None
    entropy_high_count = 0
    have_ema = False
    ema_pmix = {k: 1.0/len(ROOM_IDS) for k in ROOM_IDS} # Exponential Moving Average of probabilities

    # --- Initial Model Training ---
    send_telegram_message(chat_id, "🧠 Đang tải dữ liệu lịch sử và huấn luyện mô hình AI Ensemble...")
    historical_records_db = get_historical_data(chat_id, limit=config.HISTORICAL_DATA_LIMIT_FOR_TRAINING)
    train_prediction_model(chat_id, historical_records_db)
    user_session["last_retrain_issue_count"] = len(historical_records_db) # Record initial training count
    send_telegram_message(chat_id, "✅ Hoàn tất huấn luyện mô hình AI Ensemble. Bắt đầu đặt cược.")

    # --- Main Betting Loop ---
    while running_bots.get(chat_id, False):
        try:
            # 1. Fetch Recent 10 Issues
            hist10 = requestsGET(api_endpoints_game["recent_10"], header_room_game).get("data", [])
        except Exception as e:
            send_telegram_message(chat_id, f"⚠ Lỗi lấy recent_10: {e}. Thử lại sau 5s.")
            time.sleep(5); continue

        cur_issue = None
        if hist10:
            try: cur_issue = hist10[0]["issue_id"]
            except Exception: cur_issue = None

        # Update UI issue if changed
        if cur_issue != last_ui_issue:
            send_telegram_message(chat_id, f"🎬 Bắt đầu ISSUE mới: *{cur_issue}*")
            last_ui_issue = cur_issue

        # If current issue already processed, wait for next one
        if cur_issue is not None and cur_issue == last_processed_issue:
            time.sleep(1.0); continue

        try:
            # 2. Fetch Recent 100 Issues (for base counts)
            hist100_raw = requestsGET(api_endpoints_game["recent_100"], header_room_game).get("data", {}).get("room_id_2_killed_times", {})
        except Exception as e:
            send_telegram_message(chat_id, f"❌ Lỗi lấy recent_100: {e}. Thử lại sau 5s.")
            time.sleep(5); continue

        base_counts = {str(k): float(hist100_raw.get(str(k),0.0)) for k in range(1,9)}
        union_seq = [str(x["killed_room_id"]) for x in reversed(hist10)]
        last_room = str(hist10[0]["killed_room_id"]) if hist10 else None

        # --- 3. Ensemble Prediction ---
        all_historical_data = get_historical_data(chat_id, limit=config.HISTORICAL_DATA_LIMIT_FOR_FEATURES)
        # Create a temporary record for current issue to generate features
        temp_record_for_features = GameRecord(
            issue_id=cur_issue, timestamp=datetime.now(), killed_room_id='unknown',
            chosen_room_id='unknown', bet_amount=0, award_amount=0, pnl_trade=0,
            p_survive_predicted=0, ev_lower=0, skip_reason='', telegram_chat_id=chat_id
        )
        combined_history = all_historical_data + [temp_record_for_features]
        combined_features_df = create_features(combined_history)
        
        pmix = {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS} # Default uniform
        if not combined_features_df.empty and feature_names:
            current_features_for_pred_row = combined_features_df.iloc[-1]
            try:
                pmix = predict_next_kill_probabilities(chat_id, current_features_for_pred_row)
            except Exception as e:
                console.print(f"[red][{chat_id}] Error during ensemble prediction: {e}. Using uniform probabilities.[/red]")
        else:
            console.print(f"[yellow][{chat_id}] Not enough features or model not ready for ensemble prediction. Using uniform probabilities.[/yellow]")

        # --- 4. Calibration & Smoothing ---
        Topt = find_best_temperature(build_components(), {n: 1.0/len(build_components()) for n in build_components()}, hist10, base_counts, union_seq, config.TEMP_RANGE)
        pmix = temperature_calibrate(pmix, Topt)

        if len(hist10) >= config.ISOTONIC_MIN_SAMPLES:
            calib_pairs_multi = []
            seq = list(reversed(hist10)); union = list(union_seq)
            wts = learn_weights_EG(build_components(), hist10, base_counts, union_seq, steps=60, eta=0.5)
            for i in range(1, len(seq)):
                last_room_i = str(seq[i-1].get("killed_room_id")); union.append(last_room_i)
                wdw = list(reversed(seq[:i]))
                ctx_i = {"base_counts": base_counts, "recent_window": wdw, "last_room": last_room_i, "union_seq": union}
                preds_i = {n: normalize(fn(ctx_i)) for n,fn in build_components().items()}
                p_i = {k: 0.0 for k in ROOM_IDS}
                for n,dist in preds_i.items():
                    for k in ROOM_IDS: p_i[k] += wts[n]*dist[k]
                p_i = temperature_calibrate(normalize(p_i), Topt)
                true_k = str(seq[i].get("killed_room_id"))
                calib_pairs_multi.append((p_i[true_k], 1.0))
                for k in ROOM_IDS:
                    if k == true_k: continue
                    calib_pairs_multi.append((p_i[k], 0.0))
            xs = [a for a,_ in calib_pairs_multi]; ys = [b for _,b in calib_pairs_multi]
            iso_x, iso_y = isotonic_regression_pav(xs, ys, ws=None)
            kill_vals = [pmix[k] for k in ROOM_IDS]
            cal_vals = apply_isotonic(iso_x, iso_y, kill_vals)
            pmix = normalize({k: cv for k,cv in zip(ROOM_IDS, cal_vals)})

        ts_pref = thompson_sampling_dirichlet(base_counts, prior=1.0, samples=config.TS_SAMPLES)
        pmix = normalize({k: 0.85*pmix[k] + 0.15*ts_pref.get(k,0.0) for k in ROOM_IDS})
        if not have_ema:
            ema_pmix = pmix.copy(); have_ema = True
        else:
            for k in ROOM_IDS:
                ema_pmix[k] = ema_alpha*pmix[k] + (1-ema_alpha)*ema_pmix[k]
            pmix = normalize(ema_pmix)

        # --- 5. Risk Guards & Uncertainty Detection ---
        H = entropy(pmix)
        cp_alert = change_point_alert_wrapper(hist10)
        uncertain = False
        skip_reason_str = ""
        if entropy_skip is not None and H >= entropy_skip:
            entropy_high_count += 1
            if entropy_high_count >= entropy_hysteresis_k:
                uncertain = True
                skip_reason_str += "Entropy cao; "
        else:
            entropy_high_count = 0
        if cp_alert:
            uncertain = True
            skip_reason_str += "Change Point; "

        # --- 6. Choose Room ---
        best_key, p_survive, trust = choose_room_wrapper(pmix, base_counts, trust)
        best_name = ROOM_MAP.get(best_key, best_key)

        # --- 7. Calculate Lower Bound Probability & EV ---
        k_success = sum(1 for x in picks_window if x); n_total = max(1, len(picks_window))
        ps_lb_wilson = wilson_lower_bound_wrapper(k_success, n_total)
        n_eff = 2.0 + base_counts.get(best_key, 0.0)
        p_beta_lb = beta_lower_quantile_from_mean_n_wrapper(p_survive, n_eff)
        if calib_pairs:
            rs = sorted([ (pp - yy) for (pp,yy) in calib_pairs ])
            idx = min(len(rs)-1, max(0, int(math.ceil((1-config.CONFORMAL_ALPHA)*len(rs)))-1))
            q = rs[idx]; p_conf_lb = max(0.0, min(1.0, p_survive - q))
        else:
            p_conf_lb = p_survive * 0.9
        p_lower = max(0.01, min(0.99, max(ps_lb_wilson, p_beta_lb, p_conf_lb)))

        odds_ratio = estimate_odds_ratio(header_room_game, api_endpoints_game, bet_asset_game, header_user_game)
        ev_lower = p_lower*odds_ratio - (1 - p_lower)

        # --- 8. Adaptive Kelly Fraction Adjustment ---
        current_kelly_fraction = user_game_config.get("kelly_fraction", config.DEFAULT_KELLY_FRACTION)
        
        # Adjust based on confidence (entropy) and EV
        if H < config.ADAPTIVE_KELLY_ENTROPY_THRESHOLD_LOW and ev_lower > config.ADAPTIVE_KELLY_EV_THRESHOLD_HIGH:
            current_kelly_fraction = min(config.ADAPTIVE_KELLY_MAX_FRACTION, current_kelly_fraction * 1.2)
        elif H > config.ADAPTIVE_KELLY_ENTROPY_THRESHOLD_HIGH or ev_lower < config.ADAPTIVE_KELLY_EV_THRESHOLD_LOW:
            current_kelly_fraction = max(config.ADAPTIVE_KELLY_MIN_FRACTION, current_kelly_fraction * 0.8)
        
        # Update in user_game_config and DB for persistence
        user_game_config["kelly_fraction"] = current_kelly_fraction
        update_user_game_config(chat_id, {"kelly_fraction": current_kelly_fraction})
        user_session["kelly_fraction"] = current_kelly_fraction # Update in-memory session

        # --- 9. Determine Bet Amount ---
        bet_amount = 0
        reason = ""
        
        if skip_mode == "hard" and (uncertain or ev_lower <= config.EV_FLOOR):
            msg = f"⚠ Skip (HARD): H={H:.2f}, CP={cp_alert}, EV_LB={ev_lower:.3f}"
            send_telegram_message(chat_id, msg)
            last_processed_issue = cur_issue
            save_game_record({
                'issue_id': cur_issue, 'killed_room_id': None, 'chosen_room_id': best_key,
                'bet_amount': 0, 'award_amount': 0, 'pnl_trade': 0,
                'p_survive_predicted': p_survive, 'ev_lower': ev_lower, 'skip_reason': "HARD_SKIP",
                'timestamp': datetime.now(), 'telegram_chat_id': chat_id
            })
            continue
        if skip_mode == "off" and ev_lower <= config.EV_FLOOR:
            msg = f"⛔ Bỏ vì EV_LB={ev_lower:.3f} ≤ 0"
            send_telegram_message(chat_id, msg)
            last_processed_issue = cur_issue
            save_game_record({
                'issue_id': cur_issue, 'killed_room_id': None, 'chosen_room_id': best_key,
                'bet_amount': 0, 'award_amount': 0, 'pnl_trade': 0,
                'p_survive_predicted': p_survive, 'ev_lower': ev_lower, 'skip_reason': "EV_FLOOR",
                'timestamp': datetime.now(), 'telegram_chat_id': chat_id
            })
            continue

        if skip_mode == "soft" and uncertain:
            bet_amount = stake_min
            reason = "SOFTSKIP: mơ hồ → cược tối thiểu"
            skip_reason_str += "Soft Skip; "
        else:
            if odds_ratio > 1.0 and p_lower > (1.0 / odds_ratio):
                b = odds_ratio - 1.0
                p = p_lower
                q = 1.0 - p_lower
                f = (b * p - q) / b
                
                f_kelly = f * current_kelly_fraction # Use adaptive Kelly
                
                try:
                    w = requestsGET(api_endpoints_game["user_wallet"], header_user_game).get("data", {}).get("cwallet", {})
                    wallet_cur = {"USDT": w.get("ctoken_kusdt", 0.0), "WORLD": w.get("ctoken_kther", 0.0), "BUILD": w.get("ctoken_contribute", 0.0)}.get(bet_asset_game, 0.0)
                except Exception as e:
                    console.print(f"[red][{chat_id}] Error fetching wallet balance: {e}. Assuming 0.[/red]")
                    wallet_cur = 0.0
                
                if wallet_cur > 0:
                    calculated_bet = wallet_cur * f_kelly
                    bet_amount = int(clamp(round(calculated_bet), stake_min, stake_max))
                    reason = f"Kelly ({current_kelly_fraction*100:.0f}%)"
                else:
                    bet_amount = stake_min
                    reason = "Không có ví → cược tối thiểu"
            else:
                bet_amount = stake_min
                reason = "EV không dương → cược tối thiểu"
        
        cap_amt = config.MAX_BANKROLL_FRACTION * wallet_cur if wallet_cur else stake_max
        bet_amount = int(clamp(min(bet_amount, cap_amt) if cap_amt > 0 else bet_amount, stake_min, stake_max))

        # --- 10. Send Prediction & Bet Info to User ---
        if teacher_mode:
            pred_msg = f"🔮 Dự báo ISSUE *{cur_issue}*:\n"
            for k in ROOM_IDS:
                pk = pmix[k]; ps = 1.0 - pk; nm = ROOM_MAP.get(k,k)
                pred_msg += f"  {nm}: p_kill={pk:.3f}, p_survive={ps:.3f}"
                if k == best_key: pred_msg += " (CHỌN)"
                pred_msg += "\n"
            pred_msg += f"\n🎓 Chọn [{best_key}] {best_name} | p_sống={p_survive:.2%} | p_LB={p_lower:.2%} | " \
                        f"EV_LB={ev_lower:.3f} | odds≈{odds_ratio:.2f} | cược={bet_amount} ({reason})"
            send_telegram_message(chat_id, pred_msg)

        # --- 11. Place Bet ---
        data_room = json.dumps({"asset_type": bet_asset_game, "user_id": int(user_id_game), "room_id": int(best_key), "bet_amount": int(bet_amount)})
        try:
            res = requestsPOST(api_endpoints_game["bet"], header_room_game, data_room)
            if res.get("msg") != "ok":
                send_telegram_message(chat_id, f"❌ Đặt cược lỗi: {res.get('code','unknown')}")
                last_processed_issue = cur_issue
                save_game_record({
                    'issue_id': cur_issue, 'killed_room_id': None, 'chosen_room_id': best_key,
                    'bet_amount': bet_amount, 'award_amount': 0, 'pnl_trade': -bet_amount,
                    'p_survive_predicted': p_survive, 'ev_lower': ev_lower, 'skip_reason': f"Bet Error: {res.get('code','unknown')}",
                    'timestamp': datetime.now(), 'telegram_chat_id': chat_id
                })
                continue
        except Exception as e:
            send_telegram_message(chat_id, f"❌ Lỗi khi gửi lệnh đặt cược: {e}")
            last_processed_issue = cur_issue
            save_game_record({
                'issue_id': cur_issue, 'killed_room_id': None, 'chosen_room_id': best_key,
                'bet_amount': bet_amount, 'award_amount': 0, 'pnl_trade': -bet_amount,
                'p_survive_predicted': p_survive, 'ev_lower': ev_lower, 'skip_reason': f"Bet API Error: {e}",
                'timestamp': datetime.now(), 'telegram_chat_id': chat_id
            })
            continue

        user_session["total_staked"] += float(bet_amount)

        # --- 12. Wait for Issue Rollover ---
        send_telegram_message(chat_id, "⏳ Đang chờ chốt ISSUE…")
        current_issue_id_before_wait = cur_issue
        wait_start_time = time.time()
        while running_bots.get(chat_id, False):
            time.sleep(2)
            try:
                latest_my_joined = requestsGET(api_endpoints_game["my_joined"], header_room_game).get("data", {}).get("items", [])
                if latest_my_joined and latest_my_joined[0]["issue_id"] != current_issue_id_before_wait:
                    send_telegram_message(chat_id, f"✅ ISSUE *{current_issue_id_before_wait}* đã chốt. ISSUE mới: *{latest_my_joined[0]['issue_id']}*")
                    break
            except Exception as e:
                console.print(f"[yellow][{chat_id}] Error checking for rollover: {e}. Retrying...[/yellow]")
            
            if time.time() - wait_start_time > 120: # Max wait 120 seconds
                send_telegram_message(chat_id, "⚠️ Hết thời gian chờ rollover, tiếp tục phiên mới...")
                break

        if not running_bots.get(chat_id, False): # Bot stopped during wait
            break

        # --- 13. Process Bet Result ---
        try:
            hist = requestsGET(api_endpoints_game["my_joined"], header_room_game)["data"]["items"][0]
            killed = str(hist["killed_room_id"]); issue_id = hist.get("issue_id")
            award = float(hist.get("award_amount", 0.0) or 0.0)
        except Exception as e:
            send_telegram_message(chat_id, f"⚠ Lỗi đọc kết quả: {e}")
            last_processed_issue = cur_issue
            save_game_record({
                'issue_id': cur_issue, 'killed_room_id': None, 'chosen_room_id': best_key,
                'bet_amount': bet_amount, 'award_amount': 0, 'pnl_trade': -bet_amount,
                'p_survive_predicted': p_survive, 'ev_lower': ev_lower, 'skip_reason': f"Result Read Error: {e}",
                'timestamp': datetime.now(), 'telegram_chat_id': chat_id
            })
            continue

        room_name = ROOM_MAP.get(killed, f"Phòng {killed}")
        survived = (killed != best_key)
        picks_window.append(survived)
        calib_pairs.append((p_survive, 1.0 if survived else 0.0))

        trade_pnl = 0
        if survived:
            trade_pnl = award - bet_amount
            user_session["wins"] += 1; user_session["lose_streak"] = 0
            pnl_text = f"+{trade_pnl:.3f}" if trade_pnl >= 0 else f"{trade_pnl:.3f}"
            send_telegram_message(chat_id, f"✅ Sống sót — Nhận {award:.3f} {bet_asset_game} | Cược {bet_amount} → Lời/Lỗ {pnl_text} {bet_asset_game}")
        else:
            trade_pnl = -bet_amount
            user_session["losses"] += 1; user_session["lose_streak"] += 1
            send_telegram_message(chat_id, f"⛔ Sát thủ vào {room_name} — THUA | Cược {bet_amount} → Lỗ {abs(trade_pnl):.3f} {bet_asset_game}")

        user_session["pnl_asset"] += trade_pnl
        
        # Update session stats from DB after each trade
        db_stats = get_session_stats(chat_id)
        user_session.update(db_stats)

        # --- 14. Save Game Record ---
        save_game_record({
            'issue_id': cur_issue, 'killed_room_id': killed, 'chosen_room_id': best_key,
            'bet_amount': bet_amount, 'award_amount': award, 'pnl_trade': trade_pnl,
            'p_survive_predicted': p_survive, 'ev_lower': ev_lower, 'skip_reason': skip_reason_str if skip_reason_str else "None",
            'timestamp': datetime.now(), 'telegram_chat_id': chat_id
        })

        # --- 15. Check Take Profit / Stop Loss ---
        try:
            if user_session["pnl_asset"] >= take_profit:
                send_telegram_message(chat_id, f"🎯 CHỐT LỜI +{user_session['pnl_asset']:.3f} {bet_asset_game} (≥ {take_profit}) — dừng.")
                running_bots[chat_id] = False
            if user_session["pnl_asset"] <= -abs(stop_loss):
                send_telegram_message(chat_id, f"🛑 CHỐT LỖ {user_session['pnl_asset']:.3f} {bet_asset_game} (≤ -{abs(stop_loss)}) — dừng.")
                running_bots[chat_id] = False
        except Exception as e:
            console.print(f"[red][{chat_id}] Error checking TP/SL: {e}[/red]")

        last_processed_issue = cur_issue

        # --- 16. Model Retraining Logic ---
        current_total_records = len(get_historical_data(chat_id)) # Get current total records
        if (current_total_records - user_session["last_retrain_issue_count"]) >= config.MODEL_RETRAIN_INTERVAL_ISSUES:
            send_telegram_message(chat_id, "🔄 Đang huấn luyện lại mô hình AI Ensemble với dữ liệu mới...")
            historical_records_db = get_historical_data(chat_id, limit=config.HISTORICAL_DATA_LIMIT_FOR_TRAINING)
            train_prediction_model(chat_id, historical_records_db)
            user_session["last_retrain_issue_count"] = current_total_records # Update last retrain count
            send_telegram_message(chat_id, "✅ Hoàn tất huấn luyện lại mô hình AI Ensemble.")
        # --- End Model Retraining ---

    # --- Loop End: Bot Stopped ---
    send_telegram_message(chat_id, "🏁 Chế độ đặt cược đã dừng.")
    running_bots.pop(chat_id, None)
    set_user_bot_running_status(chat_id, False) # Update status in DB
    console.print(f"[bold blue][{chat_id}] bet_loop_core stopped.[/bold blue]")

# --- Bot Control Functions ---
def start_betting(chat_id: str):
    """Starts the betting loop for a specific user in a new thread."""
    global telegram_bot_instance, running_bots
    if running_bots.get(chat_id, False):
        send_telegram_message(chat_id, "Bot đang chạy rồi!")
        return

    running_bots[chat_id] = True
    set_user_bot_running_status(chat_id, True) # Update status in DB
    thread = threading.Thread(target=bet_loop_core, args=(chat_id,))
    thread.daemon = True # Allow main program to exit even if this thread is running
    thread.start()
    send_telegram_message(chat_id, "🚀 Bot đã bắt đầu đặt cược!")
    console.print(f"[bold green][{chat_id}] Bot started.[/bold green]")

def stop_betting(chat_id: str):
    """Stops the betting loop for a specific user."""
    global running_bots
    if not running_bots.get(chat_id, False):
        send_telegram_message(chat_id, "Bot chưa chạy.")
        return

    running_bots[chat_id] = False # Signal the thread to stop
    # The thread will clean up and update DB status itself
    send_telegram_message(chat_id, "🛑 Yêu cầu dừng bot đã được gửi. Bot sẽ dừng sau phiên hiện tại.")
    console.print(f"[bold yellow][{chat_id}] Stop request sent.[/bold yellow]")