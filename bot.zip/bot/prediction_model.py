# prediction_model.py
import pandas as pd
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from collections import deque
from datetime import datetime
import optuna # For hyperparameter optimization

from utils import ROOM_IDS, normalize, console # Import console for logging
from data_manager import get_historical_data, GameRecord # Import to get user-specific history
import config # For training parameters

# --- Global Models Storage ---
# Models are stored per chat_id to support multiple users
base_models = {} # {chat_id: {'xgb': model, 'lgbm': model, 'rf': model}}
meta_learner = {} # {chat_id: meta_model}
scaler = {} # {chat_id: scaler_object}
feature_names = [] # Global feature names, assuming consistent features across users

# --- Feature Engineering ---
def create_features(historical_records: list[GameRecord]) -> pd.DataFrame:
    """Generates features from historical game records."""
    if not historical_records:
        return pd.DataFrame()

    records_as_dicts = []
    for r in historical_records:
        record_dict = {
            'issue_id': r.issue_id,
            'timestamp': r.timestamp,
            'killed_room_id': r.killed_room_id,
            'chosen_room_id': r.chosen_room_id,
            'bet_amount': r.bet_amount,
            'award_amount': r.award_amount,
            'pnl_trade': r.pnl_trade,
            'p_survive_predicted': r.p_survive_predicted,
            'ev_lower': r.ev_lower,
            'skip_reason': r.skip_reason,
            'telegram_chat_id': r.telegram_chat_id
        }
        records_as_dicts.append(record_dict)

    df = pd.DataFrame(records_as_dicts)
    df = df.sort_values(by='timestamp', ascending=True).reset_index(drop=True)

    features = pd.DataFrame()
    features['issue_id'] = df['issue_id']
    features['killed_room_id'] = df['killed_room_id']
    features['telegram_chat_id'] = df['telegram_chat_id']

    # --- Lagged Features ---
    for room_id in ROOM_IDS:
        # Lagged killed room (binary: 1 if room was killed, 0 otherwise)
        for lag in range(1, 4): # Lags 1, 2, 3
            features[f'killed_room_lag{lag}_{room_id}'] = (df['killed_room_id'].shift(lag) == room_id).astype(int)

        # Count of times room was killed in last N issues
        for window in [5, 10, 20]:
            features[f'killed_count_last{window}_{room_id}'] = df['killed_room_id'].rolling(window=window, min_periods=1).apply(lambda x: (x == room_id).sum(), raw=False).shift(1)

        # Streak features: how many times in a row a room was NOT killed
        # This is a bit more complex, needs to be calculated iteratively or with custom apply
        # For simplicity, let's use a rolling sum of 'not killed'
        features[f'not_killed_streak_{room_id}'] = df['killed_room_id'].apply(lambda x: 1 if x != room_id else 0).rolling(window=20, min_periods=1).apply(lambda x: (x == 1).sum() if x.iloc[-1] == 0 else 0, raw=False).shift(1)
        # The above is a simplified streak. A true streak would be:
        # df['killed_room_id'].apply(lambda x: 1 if x == room_id else 0).groupby((df['killed_room_id'] != df['killed_room_id'].shift()).cumsum()).cumcount() + 1
        # For 'not killed' streak, it's similar but inverted.

    # --- Time-based Features (Example) ---
    # features['hour_of_day'] = df['timestamp'].dt.hour.shift(1)
    # features['day_of_week'] = df['timestamp'].dt.dayofweek.shift(1)

    # Fill NaN values (e.g., for initial lags)
    features = features.fillna(0)
    return features

# --- Hyperparameter Optimization Objective ---
def _optuna_objective(trial, X_train, X_val, y_train, y_val, model_type):
    """Objective function for Optuna hyperparameter optimization."""
    if model_type == 'xgb':
        param = {
            'objective': 'multi:softprob',
            'num_class': len(ROOM_IDS),
            'eval_metric': 'mlogloss',
            'use_label_encoder': False,
            'n_estimators': trial.suggest_int('n_estimators', 50, 200),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
            'random_state': 42
        }
        model = xgb.XGBClassifier(**param)
    elif model_type == 'lgbm':
        param = {
            'objective': 'multiclass',
            'num_class': len(ROOM_IDS),
            'n_estimators': trial.suggest_int('n_estimators', 50, 200),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
            'num_leaves': trial.suggest_int('num_leaves', 20, 60),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
            'random_state': 42
        }
        model = lgb.LGBMClassifier(**param)
    elif model_type == 'rf':
        param = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 200),
            'max_depth': trial.suggest_int('max_depth', 5, 20),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 5),
            'random_state': 42
        }
        model = RandomForestClassifier(**param)
    else:
        raise ValueError("Unknown model type")

    model.fit(X_train, y_train)
    preds = model.predict_proba(X_val)
    return log_loss(y_val, preds)

# --- Model Training and Prediction ---
def train_prediction_model(telegram_chat_id: str, historical_records: list[GameRecord]):
    """Trains the ensemble prediction model for a specific user."""
    global base_models, meta_learner, scaler, feature_names

    features_df = create_features(historical_records)

    if features_df.empty or len(features_df) < config.MIN_RECORDS_FOR_TRAINING:
        console.print(f"[{telegram_chat_id}] Not enough historical data ({len(features_df)} records) to train Ensemble model. Minimum required: {config.MIN_RECORDS_FOR_TRAINING}.")
        base_models[telegram_chat_id] = {}; meta_learner[telegram_chat_id] = None; scaler[telegram_chat_id] = None
        return

    # Filter out records with 'unknown' killed_room_id (from temporary records)
    features_df_cleaned = features_df[features_df['killed_room_id'] != 'unknown'].copy()
    
    if features_df_cleaned.empty:
        console.print(f"[{telegram_chat_id}] No valid historical data after cleaning to train Ensemble model.")
        base_models[telegram_chat_id] = {}; meta_learner[telegram_chat_id] = None; scaler[telegram_chat_id] = None
        return

    X = features_df_cleaned.drop(columns=['issue_id', 'killed_room_id', 'telegram_chat_id'])
    y = features_df_cleaned['killed_room_id'].astype('category').cat.codes
    
    # Update global feature_names if it's empty or needs to be set
    if not feature_names:
        feature_names.extend(X.columns.tolist())

    # Ensure all features are numeric
    X = X.apply(pd.to_numeric, errors='coerce').fillna(0)

    # Split data for training and meta-learner validation
    test_size_val = 0.3
    stratify_val = y if len(y.unique()) >= 2 else None # Stratify only if enough classes
    
    try:
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=test_size_val, random_state=42, stratify=stratify_val)
    except ValueError as e:
        console.print(f"[red][{telegram_chat_id}] Error splitting data for training: {e}. Not enough samples for stratification? Trying without stratification.[/red]")
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=test_size_val, random_state=42)


    # --- Train Base Models with Optuna ---
    current_base_models = {}
    console.print(f"[{telegram_chat_id}] Training Base Models...")
    
    # XGBoost
    try:
        study_xgb = optuna.create_study(direction='minimize', sampler=optuna.samplers.TPESampler(seed=42))
        study_xgb.optimize(lambda trial: _optuna_objective(trial, X_train, X_val, y_train, y_val, 'xgb'), n_trials=config.OPTUNA_N_TRIALS, show_progress_bar=False)
        xgb_model = xgb.XGBClassifier(**study_xgb.best_params, objective='multi:softprob', num_class=len(ROOM_IDS), eval_metric='mlogloss', use_label_encoder=False, random_state=42)
        xgb_model.fit(X_train, y_train)
        current_base_models['xgb'] = xgb_model
        console.print(f"[{telegram_chat_id}] XGBoost trained with best params: {study_xgb.best_params}")
    except Exception as e:
        console.print(f"[red][{telegram_chat_id}] Error training XGBoost: {e}. Skipping XGBoost for this user.[/red]")

    # LightGBM
    try:
        study_lgbm = optuna.create_study(direction='minimize', sampler=optuna.samplers.TPESampler(seed=42))
        study_lgbm.optimize(lambda trial: _optuna_objective(trial, X_train, X_val, y_train, y_val, 'lgbm'), n_trials=config.OPTUNA_N_TRIALS, show_progress_bar=False)
        lgbm_model = lgb.LGBMClassifier(**study_lgbm.best_params, objective='multiclass', num_class=len(ROOM_IDS), random_state=42)
        lgbm_model.fit(X_train, y_train)
        current_base_models['lgbm'] = lgbm_model
        console.print(f"[{telegram_chat_id}] LightGBM trained with best params: {study_lgbm.best_params}")
    except Exception as e:
        console.print(f"[red][{telegram_chat_id}] Error training LightGBM: {e}. Skipping LightGBM for this user.[/red]")

    # Random Forest
    try:
        study_rf = optuna.create_study(direction='minimize', sampler=optuna.samplers.TPESampler(seed=42))
        study_rf.optimize(lambda trial: _optuna_objective(trial, X_train, X_val, y_train, y_val, 'rf'), n_trials=config.OPTUNA_N_TRIALS, show_progress_bar=False)
        rf_model = RandomForestClassifier(**study_rf.best_params, random_state=42)
        rf_model.fit(X_train, y_train)
        current_base_models['rf'] = rf_model
        console.print(f"[{telegram_chat_id}] Random Forest trained with best params: {study_rf.best_params}")
    except Exception as e:
        console.print(f"[red][{telegram_chat_id}] Error training Random Forest: {e}. Skipping Random Forest for this user.[/red]")

    base_models[telegram_chat_id] = current_base_models

    if not current_base_models:
        console.print(f"[red][{telegram_chat_id}] No base models trained successfully. Cannot train meta-learner.[/red]")
        meta_learner[telegram_chat_id] = None; scaler[telegram_chat_id] = None
        return

    # --- Create Input for Meta-Learner ---
    val_preds = []
    for name, model in current_base_models.items():
        val_preds.append(model.predict_proba(X_val))
    
    X_meta = np.hstack(val_preds)

    # --- Train Meta-Learner ---
    console.print(f"[{telegram_chat_id}] Training Meta-Learner...")
    current_scaler = StandardScaler()
    X_meta_scaled = current_scaler.fit_transform(X_meta)

    current_meta_learner = LogisticRegression(solver='lbfgs', multi_class='multinomial', max_iter=1000, random_state=42)
    current_meta_learner.fit(X_meta_scaled, y_val)
    console.print(f"[{telegram_chat_id}] Meta-Learner trained.")

    meta_learner[telegram_chat_id] = current_meta_learner
    scaler[telegram_chat_id] = current_scaler

    console.print(f"[{telegram_chat_id}] Ensemble model (Stacking) trained successfully.")

def predict_next_kill_probabilities(telegram_chat_id: str, current_features_df_row: pd.Series) -> dict[str, float]:
    """Predicts kill probabilities using the ensemble model for a specific user."""
    global base_models, meta_learner, scaler, feature_names

    current_base_models = base_models.get(telegram_chat_id)
    current_meta_learner = meta_learner.get(telegram_chat_id)
    current_scaler = scaler.get(telegram_chat_id)

    if not current_base_models or current_meta_learner is None or current_scaler is None or not feature_names:
        console.print(f"[yellow][{telegram_chat_id}] Model not available or not trained. Returning uniform probabilities.[/yellow]")
        return {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS}

    # Ensure the input features match the training features
    X_pred_base = current_features_df_row[feature_names].to_frame().T
    X_pred_base = X_pred_base.apply(pd.to_numeric, errors='coerce').fillna(0) # Ensure numeric

    test_preds = []
    for name, model in current_base_models.items():
        try:
            test_preds.append(model.predict_proba(X_pred_base))
        except Exception as e:
            console.print(f"[red][{telegram_chat_id}] Error predicting with base model {name}: {e}. Using uniform prediction for this model.[/red]")
            test_preds.append(np.full((1, len(ROOM_IDS)), 1.0/len(ROOM_IDS)))
    
    if not test_preds: # If all base models failed
        console.print(f"[red][{telegram_chat_id}] All base models failed prediction. Returning uniform probabilities.[/red]")
        return {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS}

    X_meta = np.hstack(test_preds)
    X_meta_scaled = current_scaler.transform(X_meta)

    final_probs = current_meta_learner.predict_proba(X_meta_scaled)[0]
    
    pmix = {ROOM_IDS[i]: prob for i, prob in enumerate(final_probs)}
    return normalize(pmix)