# config.py
import os

# --- Telegram Bot Configuration ---
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "7198585340:AAHOtGMhS1WfgFA52coWkLpdOjhY5vBGMHc")
# Danh sách các chat ID của admin. Có thể lấy từ biến môi trường hoặc hardcode.
# Ví dụ: ADMIN_CHAT_IDS = os.getenv("ADMIN_CHAT_IDS", "123456789,987654321").split(',')
ADMIN_CHAT_IDS = ["5573777234"] # Thay thế bằng chat ID của bạn

# --- Database Configuration ---
USER_DB_FILE = "telegram_users.db"
GAME_HISTORY_DB_FILE = "game_history.db"

# --- Default Game Configuration (User-configurable) ---
# These are default values for new users or if a user hasn't set them.
DEFAULT_URL_GAME = "" # User must set this
DEFAULT_BET_TYPE = "BUILD" # BUILD, USDT, WORLD

DEFAULT_STAKE_MIN = 30
DEFAULT_STAKE_MAX = 50
DEFAULT_TAKE_PROFIT = 30.0
DEFAULT_STOP_LOSS = 50.0
DEFAULT_KELLY_FRACTION = 0.5 # Initial Kelly fraction, will be adaptive

# --- AI/Risk Management Configuration ---
MAX_BANKROLL_FRACTION = 0.02 # Max fraction of current bankroll to bet
WILSON_Z = 1.64 # Z-score for Wilson lower bound (~90% confidence)
TS_SAMPLES = 200 # Samples for Thompson Sampling
TEMP_RANGE = (0.6, 1.6, 15) # Temperature calibration range (min, max, steps)
ISOTONIC_MIN_SAMPLES = 14 # Min samples for Isotonic Regression
CP_LLR_SKIP_Z = 2.2 # Change Point Likelihood Ratio Z-score for skipping
ENTROPY_SKIP = 2.03 # Entropy threshold for marking as uncertain
ENTROPY_HYSTERESIS_K = 3 # Number of consecutive high entropy issues to trigger uncertainty
CONFORMAL_ALPHA = 0.10 # Alpha for Conformal Prediction lower bound
EV_FLOOR = 0.0 # Minimum Expected Value to consider betting
EMA_ALPHA = 0.55 # Alpha for Exponential Moving Average
SKIP_MODE = "soft" # "soft" | "hard" | "off" - How to handle uncertain situations
TEACHER_MODE = True # If True, bot sends detailed prediction info

# --- Adaptive Kelly Configuration ---
ADAPTIVE_KELLY_MIN_FRACTION = 0.1 # Minimum Kelly fraction
ADAPTIVE_KELLY_MAX_FRACTION = 1.0 # Maximum Kelly fraction
ADAPTIVE_KELLY_ENTROPY_THRESHOLD_LOW = 1.5 # Low entropy -> more confident -> increase Kelly
ADAPTIVE_KELLY_ENTROPY_THRESHOLD_HIGH = 2.0 # High entropy -> less confident -> decrease Kelly
ADAPTIVE_KELLY_EV_THRESHOLD_HIGH = 0.05 # High EV -> more confident -> increase Kelly
ADAPTIVE_KELLY_EV_THRESHOLD_LOW = 0.01 # Low EV -> less confident -> decrease Kelly

# --- API Request Configuration ---
API_RETRY_ATTEMPTS = 5 # Number of retries for API calls
API_RETRY_BACKOFF_FACTOR = 0.5 # Backoff factor for retries (0.5s, 1s, 2s, ...)
API_TIMEOUT = 45 # Timeout for each API request in seconds

# --- AI Model Training Configuration ---
MIN_RECORDS_FOR_TRAINING = 100 # Minimum historical records to train the ensemble model
HISTORICAL_DATA_LIMIT_FOR_TRAINING = 2000 # Max records to fetch for training
HISTORICAL_DATA_LIMIT_FOR_FEATURES = 500 # Max records to fetch for feature generation
MODEL_RETRAIN_INTERVAL_ISSUES = 100 # Retrain model every X issues
OPTUNA_N_TRIALS = 10 # Number of trials for Optuna hyperparameter optimization (reduce for Termux)
