# utils.py
import os
import sys
import time
import json
import math
import random
import subprocess
from urllib.parse import urlparse, parse_qs
from collections import Counter, defaultdict

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.align import Align
from rich.columns import Columns
from rich.text import Text
from rich import box

# Import config for API settings
import config

# --- Console Setup ---
console = Console()

# --- Global Game Constants ---
ROOM_MAP = {
    "1": "Nhà Kho", "2": "Phòng Họp", "3": "Phòng Giám Đốc", "4": "Phòng Trò Chuyện",
    "5": "Phòng Giám Sát", "6": "Văn Phòng", "7": "Phòng Tài Vụ", "8": "Phòng Nhân Sự",
}
ROOM_IDS = [str(i) for i in range(1, 9)]

# --- Utility Functions ---
def _ensure_package(pkg, modname=None):
    """Ensures a Python package is installed."""
    modname = modname or pkg
    try:
        __import__(modname)
    except ImportError:
        console.print(f"[yellow]Package '{pkg}' not found. Installing...[/yellow]")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
        console.print(f"[green]Package '{pkg}' installed.[/green]")
        __import__(modname)

def requests_retry_session(
    retries=config.API_RETRY_ATTEMPTS,
    backoff_factor=config.API_RETRY_BACKOFF_FACTOR,
    status_forcelist=(500, 502, 503, 504),
    session=None,
):
    """Configures a requests session with retry logic."""
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        method_whitelist=frozenset(['GET', 'POST']) # Apply retry to GET and POST
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session

def requestsGET(url, headers):
    """Performs a GET request with retry logic."""
    try:
        response = requests_retry_session().get(url=url, headers=headers, timeout=config.API_TIMEOUT)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
        return response.json()
    except requests.exceptions.RequestException as e:
        console.print(f"[red]API GET Error for {url}: {e}[/red]")
        raise # Re-raise the exception to be handled by calling function

def requestsPOST(url, headers, data):
    """Performs a POST request with retry logic."""
    try:
        response = requests_retry_session().post(url=url, headers=headers, data=data, timeout=config.API_TIMEOUT)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        console.print(f"[red]API POST Error for {url}: {e}[/red]")
        raise # Re-raise the exception

def normalize(d: dict[str, float]) -> dict[str, float]:
    """Normalizes a dictionary of probabilities."""
    s = sum(max(0.0, v) for v in d.values())
    if s <= 0: return {k: 1.0/len(d) for k in d}
    return {k: max(0.0, v)/s for k, v in d.items()}

def entropy(dist: dict[str,float], eps=1e-12) -> float:
    """Calculates the entropy of a probability distribution."""
    return -sum(p*math.log(max(eps,p)) for p in dist.values())

def clamp(v, a, b):
    """Clamps a value v between a and b."""
    return max(a, min(b, v))

# --- Game API & Configuration ---
def build_endpoints_and_headers(user_game_config):
    """Builds API endpoints and headers from user game configuration."""
    parsed_url = urlparse(user_game_config["url_game"])
    params = parse_qs(parsed_url.query)
    user_id = params.get("userId", [None])[0]
    secret_key = params.get("secretKey", [None])[0]
    if not user_id or not secret_key:
        raise ValueError("URL game thiếu userId hoặc secretKey.")
    
    # Standard headers for 3games.io / escapemaster.net
    common_headers = {
        "sec-ch-ua-platform": "\"Android\"",
        "user-id": user_id,
        "user-secret-key": secret_key,
        "sec-ch-ua": "\"Not;A=Brand\";v=\"99\", \"Google Chrome\";v=\"139\", \"Chromium\";v=\"139\"",
        "user-login": "login_v2",
        "sec-ch-ua-mobile": "?1",
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36",
        "accept": "*/*",
        "origin": "https://escapemaster.net",
        "referer": "https://escapemaster.net/",
        "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.6,en;q=0.5",
        "content-type": "application/json"
    }

    header_user = {**common_headers, "host": "user.3games.io"}
    header_room = {**common_headers, "host": "api.escapemaster.net"}
    
    asset = user_game_config["bet_type"]
    api = {
        "user_wallet": "https://user.3games.io/user/regist?is_cwallet=1&is_mission_setting=true&version=",
        "bet": "https://api.escapemaster.net/escape_game/bet",
        "recent_10": f"https://api.escapemaster.net/escape_game/recent_10_issues?asset={asset}",
        "recent_100": f"https://api.escapemaster.net/escape_game/recent_100_issues?asset={asset}",
        "my_joined": f"https://api.escapemaster.net/escape_game/my_joined?asset={asset}&page=1&page_size=10",
    }
    return user_id, header_user, header_room, api

# --- Prediction & Risk Management Helpers ---
def dirichlet_mean(counts: dict[str, float], prior=1.0) -> dict[str, float]:
    """Calculates Dirichlet mean for room probabilities."""
    alpha = {k: counts.get(k, 0.0) + prior for k in ROOM_IDS}
    s = sum(alpha.values()) or 1.0
    return {k: alpha[k]/s for k in ROOM_IDS}

def eb_shrinkage(counts: dict[str,float], prior_strength=8.0) -> dict[str,float]:
    """Applies Empirical Bayes shrinkage to counts."""
    total = sum(counts.get(k,0.0) for k in ROOM_IDS)
    if total <= 0: return {k: 1.0/len(ROOM_IDS) for k in ROOM_IDS}
    mean = total/len(ROOM_IDS)
    return {k: counts.get(k,0.0) + prior_strength*(mean/len(ROOM_IDS)) for k in ROOM_IDS}

def recency_distribution(recent_records: list, decay_lambda=0.32) -> dict[str,float]:
    """Calculates a distribution based on recency of killed rooms."""
    if not recent_records: return {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS}
    ws = [math.exp(-decay_lambda*i) for i in range(len(recent_records))]
    s = sum(ws) or 1.0; acc = defaultdict(float)
    for i, rec in enumerate(recent_records):
        rid = str(rec.get("killed_room_id")); acc[rid] += ws[i]/s
    return normalize({k: acc.get(k,0.0) for k in ROOM_IDS})

def build_markov1(sequence: list[str], smoothing=1.0) -> dict[str, dict[str,float]]:
    """Builds a 1st order Markov chain transition matrix."""
    T = {i: {j: smoothing for j in ROOM_IDS} for i in ROOM_IDS}
    for a,b in zip(sequence[:-1], sequence[1:]):
        if a in T and b in T[a]: T[a][b] += 1
    for i in ROOM_IDS:
        row = T[i]; s = sum(row.values()) or 1.0
        T[i] = {j: row[j]/s for j in ROOM_IDS}
    return T

def predict_markov1(T, last_room):
    """Predicts next room based on 1st order Markov chain."""
    if not last_room or last_room not in T: return {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS}
    return dict(T[last_room])

def build_markov2(sequence: list[str], smoothing=0.6) -> dict[tuple, dict[str,float]]:
    """Builds a 2nd order Markov chain transition matrix."""
    S = {}
    for a,b,c in zip(sequence[:-2], sequence[1:-1], sequence[2:]):
        key = (a,b)
        if key not in S: S[key] = {j: smoothing for j in ROOM_IDS}
        S[key][c] = S[key].get(c, smoothing) + 1
    for key,row in S.items():
        s = sum(row.values()) or 1.0
        S[key] = {j: row.get(j, smoothing)/s for j in ROOM_IDS}
    return S

def predict_markov2(S, last2):
    """Predicts next room based on 2nd order Markov chain."""
    if not last2 or last2 not in S: return {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS}
    return dict(S[last2])

def gap_hazard_distribution(union_sequence: list[str], recent_window: list) -> dict[str,float]:
    """Calculates hazard rates based on gaps between killed rooms."""
    if not union_sequence: return {rid: 1.0/len(ROOM_IDS) for rid in ROOM_IDS}
    gaps = {k: [] for k in ROOM_IDS}; last_pos = {k: None for k in ROOM_IDS}
    for idx, r in enumerate(union_sequence):
        if last_pos[r] is not None: gaps[r].append(idx - last_pos[r])
        last_pos[r] = idx
    lam = {}
    for k in ROOM_IDS:
        if gaps[k]:
            mean_gap = sum(gaps[k])/len(gaps[k]); lam[k] = 1.0/max(1e-6, mean_gap)
        else: lam[k] = 1.0/12.0 # Default lambda if no gaps observed
    last_seen = {k: None for k in ROOM_IDS}
    for idx, rec in enumerate(recent_window):
        rid = str(rec.get("killed_room_id"))
        if last_seen[rid] is None: last_seen[rid] = idx
    g = {k: (idx if (idx:=last_seen[k]) is not None else len(recent_window)+2) for k in ROOM_IDS}
    haz = {k: 1.0 - math.exp(-lam[k]*g[k]) for k in ROOM_IDS}
    return normalize(haz)

def gap_anti_streak_scores(recent_records: list, gap_coef=0.16, streak_penalty=0.10) -> dict[str,float]:
    """Calculates scores based on gaps and anti-streaks."""
    last_seen = {k: None for k in ROOM_IDS}
    for idx, rec in enumerate(recent_records):
        rid = str(rec.get("killed_room_id"))
        if last_seen[rid] is None: last_seen[rid] = idx
    gap = {k: (idx if (idx:=last_seen[k]) is not None else len(recent_records)+2) for k in ROOM_IDS}
    gap_score = {k: -gap_coef*math.log(1+gap[k], 1.5) for k in ROOM_IDS}
    pen = {k: 0.0 for k in ROOM_IDS}
    if recent_records:
        head = str(recent_records[0].get("killed_room_id")); cnt = 1
        for r in recent_records[1:]:
            if str(r.get("killed_room_id")) == head: cnt += 1
            else: break
        pen[head] = +streak_penalty * cnt
    return {k: gap_score.get(k,0.0) + pen.get(k,0.0) for k in ROOM_IDS}

def scores_to_prob(scores: dict[str,float]) -> dict[str,float]:
    """Converts scores to probabilities using a sigmoid-like function."""
    q = {k: 1.0/(1.0 + math.exp(-scores.get(k,0.0))) for k in ROOM_IDS}
    return normalize(q)

def log_loss(p: dict[str,float], true_k: str, eps=1e-12) -> float:
    """Calculates log loss."""
    return -math.log(max(eps, p.get(true_k, eps)))

def wilson_lower_bound(k, n, z) -> float:
    """Calculates the Wilson lower bound for a proportion."""
    if n <= 0: return 0.0
    phat = k/n
    denom = 1 + (z**2)/n
    centre = phat + (z**2)/(2*n)
    rad = z * math.sqrt((phat*(1-phat)/n) + (z**2)/(4*n*n))
    return max(0.0, min(1.0, (centre - rad)/denom))

def beta_lower_quantile_from_mean_n(m, n_eff, q) -> float:
    """Estimates a lower quantile from a Beta distribution."""
    var = m*(1-m) / (n_eff + 1.0)
    sd = math.sqrt(max(var, 1e-12))
    # Z-score for 10% (q=0.10) or 5% (q=0.05) lower tail
    z = -1.2815515655446004 if abs(q-0.10)<1e-6 else -1.6448536269514729
    return max(0.0, min(1.0, m + z*sd))

def isotonic_regression_pav(xs, ys, ws=None):
    """Pool Adjacent Violators Algorithm for Isotonic Regression."""
    n = len(xs)
    if n == 0: return [], []
    if ws is None: ws = [1.0]*n
    data = sorted(zip(xs, ys, ws), key=lambda t: t[0])
    y = [yy for _,yy,_ in data]; w = [ww for _,_,ww in data]
    i = 0
    while i < n-1:
        if y[i] <= y[i+1]: i+=1; continue
        tw = w[i] + w[i+1]
        avg = (w[i]*y[i] + w[i+1]*y[i+1]) / tw
        y[i] = avg; w[i] = tw
        del y[i+1]; del w[i+1]; del data[i+1]; n-=1
        j = i
        while j>0 and y[j-1] > y[j]:
            tw = w[j-1] + w[j]
            avg = (w[j-1]*y[j-1] + w[j]*y[j]) / tw
            y[j-1]=avg; w[j-1]=tw
            del y[j]; del w[j]; del data[j]; n-=1; j-=1
        i = max(j, 0)
    x_sorted = [xx for xx,_,_ in data]
    return x_sorted, y

def apply_isotonic(xs, ys, new_xs):
    """Applies isotonic regression results to new data points."""
    if not xs: return new_xs[:] if isinstance(new_xs, list) else new_xs
    out = []
    for x0 in new_xs:
        lo,hi,pos = 0,len(xs)-1,-1
        while lo<=hi:
            mid=(lo+hi)//2
            if xs[mid] <= x0: pos=mid; lo=mid+1
            else: hi=mid-1
        out.append(ys[0] if pos<0 else ys[pos])
    return out

def temperature_calibrate(p, T):
    """Applies temperature scaling to a probability distribution."""
    if T <= 0: T = 1.0
    q = {k: (p[k] ** (1.0/T)) for k in ROOM_IDS}
    return normalize(q)

def learn_weights_EG(components, recent_history, base_counts, union_seq, steps=100, eta=0.5):
    """Learns ensemble weights using Exponential Gradient algorithm."""
    if not recent_history: return {name: 1.0/len(components) for name in components}
    w = {name: 1.0/len(components) for name in components}
    hist = list(reversed(recent_history))
    for _ in range(steps):
        grad = {name: 0.0 for name in components}; moves = 0
        seq = list(union_seq)
        for i in range(1, len(hist)):
            last_room = str(hist[i-1].get("killed_room_id")); seq.append(last_room)
            window = list(reversed(hist[:i]))
            ctx = {"base_counts": base_counts, "recent_window": window, "last_room": last_room, "union_seq": seq}
            preds = {n: normalize(fn(ctx)) for n,fn in components.items()}
            pmix = {k: 0.0 for k in ROOM_IDS}
            for n,dist in preds.items():
                for k in ROOM_IDS: pmix[k] += w[n]*dist[k]
            pmix = normalize(pmix)
            true_k = str(hist[i].get("killed_room_id")); denom = max(1e-12, pmix[true_k])
            for n,dist in preds.items(): grad[n] += - dist[true_k] / denom
            moves += 1
        if moves == 0: break
        for n in w: w[n] *= math.exp(-eta * grad[n] / moves)
        floor = 0.04 # Minimum weight to prevent zero weights
        s = 0.0
        for n in w:
            w[n] = max(floor, w[n]); s += w[n]
        for n in w: w[n] /= s
    return w

def find_best_temperature(components, weights, recent_history, base_counts, union_seq, temp_range):
    """Finds the optimal temperature for calibration using log loss."""
    lo, hi, steps = temp_range
    if not recent_history: return 1.0
    hist = list(reversed(recent_history))
    best_T, best_loss = 1.0, float("inf")
    for s in range(steps):
        T = lo + s*(hi-lo)/(steps-1)
        tot, m = 0.0, 0
        seq = list(union_seq)
        for i in range(1, len(hist)):
            last_room = str(hist[i-1].get("killed_room_id")); seq.append(last_room)
            window = list(reversed(hist[:i]))
            ctx = {"base_counts": base_counts, "recent_window": window, "last_room": last_room, "union_seq": seq}
            preds = {n: normalize(fn(ctx)) for n,fn in components.items()}
            pmix = {k: 0.0 for k in ROOM_IDS}
            for n,dist in preds.items():
                for k in ROOM_IDS: pmix[k] += weights[n]*dist[k]
            pmix = temperature_calibrate(normalize(pmix), T)
            true_k = str(hist[i].get("killed_room_id"))
            tot += log_loss(pmix, true_k); m += 1
        if m>0 and tot < best_loss:
            best_loss, best_T = tot, T
    return best_T

def thompson_sampling_dirichlet(counts, prior=1.0, samples=config.TS_SAMPLES):
    """Performs Thompson Sampling from a Dirichlet distribution."""
    def sample_gamma(kshape, theta=1.0):
        # Gamma distribution sampler (Marsaglia and Tsang method)
        if kshape <= 0: return 0.0
        if kshape < 1.0:
            u = random.random()
            return sample_gamma(kshape+1.0, theta) * (u ** (1.0/kshape))
        d = kshape - 1.0/3.0; c = 1.0/math.sqrt(9.0*d)
        while True:
            x = random.gauss(0,1); v = (1 + c*x)
            if v <= 0: continue
            v = v*v*v; u = random.random()
            if u < 1 - 0.331*(x*x)*(x*x): return d*v*theta
            if math.log(u) < 0.5*x*x + d*(1 - v + math.log(v)): return d*v*theta
    
    alpha = {k: counts.get(k,0.0) + prior for k in ROOM_IDS}
    wins = {k: 0 for k in ROOM_IDS}
    for _ in range(samples):
        draws = {k: sample_gamma(alpha[k], 1.0) for k in ROOM_IDS}
        s = sum(draws.values()) or 1.0
        p = {k: draws[k]/s for k in ROOM_IDS}
        best = min(ROOM_IDS, key=lambda k: p[k]) # Choose room with minimum predicted kill probability
        wins[best] += 1
    return normalize({k: float(v) for k,v in wins.items()})

def build_components():
    """Returns a dictionary of base prediction components."""
    def comp_dirichlet(ctx):
        base = eb_shrinkage(ctx["base_counts"], prior_strength=8.0)
        return dirichlet_mean(base, prior=1.0)
    def comp_recency(ctx):
        candidates = [0.12, 0.18, 0.24, 0.32, 0.45, 0.62]
        hist = list(reversed(ctx["recent_window"]))
        best_lmb, best_loss = 0.32, float("inf")
        for l in candidates:
            tot,m = 0.0, 0
            seq = list(ctx["union_seq"])
            for i in range(1, len(hist)):
                last_room = str(hist[i-1].get("killed_room_id")); seq.append(last_room)
                window = list(reversed(hist[:i]))
                dist = recency_distribution(window, decay_lambda=l)
                true_k = str(hist[i].get("killed_room_id"))
                tot += log_loss(dist, true_k); m+=1
            if m>0 and tot/m < best_loss:
                best_loss = tot/m; best_lmb = l
        return recency_distribution(ctx["recent_window"], decay_lambda=best_lmb)
    def comp_markov1(ctx):
        T = build_markov1(ctx["union_seq"], smoothing=1.0)
        return predict_markov1(T, ctx["last_room"])
    def comp_markov2(ctx):
        S = build_markov2(ctx["union_seq"], smoothing=0.6)
        seq = ctx["union_seq"]; last2 = (seq[-2], seq[-1]) if len(seq)>=2 else None
        return predict_markov2(S, last2)
    def comp_hazard(ctx):
        return gap_hazard_distribution(ctx["union_seq"], ctx["recent_window"])
    def comp_gap(ctx):
        return scores_to_prob(gap_anti_streak_scores(ctx["recent_window"], 0.16, 0.10))
    return {"dirichlet": comp_dirichlet, "recency": comp_recency, "markov1": comp_markov1,
            "markov2": comp_markov2, "hazard": comp_hazard, "gap": comp_gap}

def change_point_alert(hist10, cp_llr_skip_z):
    """Detects a change point in the distribution of killed rooms."""
    if len(hist10) < 8: return False
    first = hist10[len(hist10)//2:]; second = hist10[:len(hist10)//2]
    c1 = Counter(str(x.get("killed_room_id")) for x in first)
    c2 = Counter(str(x.get("killed_room_id")) for x in second)
    p1 = [c1.get(k,0)+1 for k in ROOM_IDS]; p2 = [c2.get(k,0)+1 for k in ROOM_IDS]
    s1,s2 = sum(p1), sum(p2); p1=[x/s1 for x in p1]; p2=[x/s2 for x in p2]
    l2 = math.sqrt(sum((a-b)*(a-b) for a,b in zip(p1,p2)))
    z = l2 * math.sqrt(max(1, len(hist10)//2))
    return z >= cp_llr_skip_z

def choose_room(p_kill: dict, counts: dict, trust: dict|None=None, wilson_z=config.WILSON_Z):
    """Chooses the best room to bet on based on predicted kill probabilities and risk."""
    n = int(sum(counts.values())) if sum(counts.values())>0 else 1
    def wilson_upper(k, n, z=wilson_z):
        if n<=0: return 1.0
        phat=k/n; denom=1+(z**2)/n
        centre=phat+(z**2)/(2*n)
        rad=z*math.sqrt((phat*(1-phat)/n)+(z**2)/(4*n*n))
        return max(0.0, min(1.0, (centre+rad)/denom))
    wub = {k: wilson_upper(int(counts.get(k,0)), n) for k in ROOM_IDS}
    risk_blend = 0.62 # Blend factor for risk (0.62 * p_kill + 0.38 * WUB)
    risk = {k: risk_blend*p_kill.get(k,0.0) + (1-risk_blend)*wub.get(k,1.0) for k in ROOM_IDS}
    if trust is None: trust = {k: 1.0 for k in ROOM_IDS} # Trust scores for each room
    for k in ROOM_IDS:
        t = max(0.05, float(trust.get(k,1.0)))
        risk[k] *= (1.0/t) # Adjust risk based on trust
    best = min(ROOM_IDS, key=lambda k: (risk[k], p_kill.get(k,0.0)))
    
    # Update trust scores: decrease trust for chosen room, increase for others
    trust[best] = max(0.0, trust.get(best,1.0)*(1.0-0.12))
    for k in ROOM_IDS:
        if k==best: continue
        trust[k] = min(1.0, trust.get(k,1.0)+0.06)
    
    p_survive = max(0.0, 1.0 - p_kill.get(best,0.0))
    return best, p_survive, trust

def estimate_odds_ratio(header_room, api, bet_asset, header_user):
    """Estimates the average odds ratio from recent joined games."""
    try:
        items = requestsGET(api["my_joined"], header_room).get("data", {}).get("items", [])
        ratios = []
        for it in items[:5]: # Look at last 5 games
            bet_amt = float(it.get("bet_amount", 0.0) or 0.0)
            award = float(it.get("award_amount", 0.0) or 0.0)
            if bet_amt > 0: ratios.append(award/bet_amt)
        if ratios: return max(0.1, sum(ratios)/len(ratios)) # Return average, min 0.1
    except Exception:
        pass # Ignore errors, return default 1.0
    return 1.0 # Default odds ratio