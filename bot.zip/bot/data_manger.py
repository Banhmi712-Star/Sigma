# data_manager.py
import sqlalchemy
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import json
from pathlib import Path

import config

Base = declarative_base()

class GameRecord(Base):
    __tablename__ = 'game_records'
    id = Column(Integer, primary_key=True)
    issue_id = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.now)
    killed_room_id = Column(String)
    chosen_room_id = Column(String)
    bet_amount = Column(Float)
    award_amount = Column(Float)
    pnl_trade = Column(Float)
    p_survive_predicted = Column(Float)
    ev_lower = Column(Float)
    skip_reason = Column(String)
    telegram_chat_id = Column(String, nullable=False) # Link to Telegram user

    # Ensure unique records per issue per user
    __table_args__ = (UniqueConstraint('issue_id', 'telegram_chat_id', name='_issue_user_uc'),)

class TelegramUser(Base):
    __tablename__ = 'telegram_users'
    chat_id = Column(String, primary_key=True)
    username = Column(String)
    first_name = Column(String)
    last_name = Column(String)
    is_admin = Column(Boolean, default=False)
    game_config_json = Column(String) # Stores user's game configuration as JSON
    is_bot_running = Column(Boolean, default=False) # Bot running status for this user

# --- Database Setup ---
# Create 'data' directory if it doesn't exist
db_dir = Path.cwd() / "data"
db_dir.mkdir(exist_ok=True)

engine_game_records = create_engine(f'sqlite:///{db_dir / config.GAME_HISTORY_DB_FILE}')
engine_telegram_users = create_engine(f'sqlite:///{db_dir / config.USER_DB_FILE}')

# Create tables if they don't exist
Base.metadata.create_all(engine_game_records)
Base.metadata.create_all(engine_telegram_users)

SessionGameRecords = sessionmaker(bind=engine_game_records)
SessionTelegramUsers = sessionmaker(bind=engine_telegram_users)

# --- Game Record Management ---
def save_game_record(record_data: dict):
    """Saves a game record to the database."""
    session = SessionGameRecords()
    try:
        record = GameRecord(**record_data)
        session.add(record)
        session.commit()
    except sqlalchemy.exc.IntegrityError:
        session.rollback()
        # console.print(f"[yellow]Record for issue_id {record_data.get('issue_id')} and chat_id {record_data.get('telegram_chat_id')} already exists, skipping.[/yellow]")
    except Exception as e:
        session.rollback()
        console.print(f"[red]Error saving game record: {e}[/red]")
    finally:
        session.close()

def get_historical_data(telegram_chat_id: str, limit: int = None) -> list[GameRecord]:
    """Retrieves historical game records for a specific user."""
    session = SessionGameRecords()
    try:
        query = session.query(GameRecord).filter(GameRecord.telegram_chat_id == telegram_chat_id).order_by(GameRecord.timestamp.desc())
        if limit:
            query = query.limit(limit)
        return query.all()
    finally:
        session.close()

def get_session_stats(telegram_chat_id: str) -> dict:
    """Calculates session statistics for a specific user."""
    session = SessionGameRecords()
    try:
        query = session.query(GameRecord).filter(GameRecord.telegram_chat_id == telegram_chat_id)

        total_wins = query.filter(GameRecord.pnl_trade > 0).count()
        total_losses = query.filter(GameRecord.pnl_trade < 0).count()
        total_staked = query.with_entities(sqlalchemy.func.sum(GameRecord.bet_amount)).scalar() or 0.0
        total_pnl = query.with_entities(sqlalchemy.func.sum(GameRecord.pnl_trade)).scalar() or 0.0
        
        # Calculate current lose streak
        lose_streak = 0
        recent_records_query = session.query(GameRecord).filter(GameRecord.telegram_chat_id == telegram_chat_id).order_by(GameRecord.timestamp.desc())
        recent_records = recent_records_query.limit(100).all() # Look at last 100 records for streak

        for record in recent_records:
            if record.pnl_trade < 0:
                lose_streak += 1
            else:
                break # Streak broken

        return {
            "wins": total_wins,
            "losses": total_losses,
            "lose_streak": lose_streak,
            "total_staked": total_staked,
            "pnl_asset": total_pnl,
        }
    finally:
        session.close()

# --- Telegram User Management ---
def get_telegram_user(chat_id: str) -> TelegramUser:
    """Retrieves a Telegram user by chat ID."""
    session = SessionTelegramUsers()
    try:
        return session.query(TelegramUser).filter_by(chat_id=chat_id).first()
    finally:
        session.close()

def create_or_update_telegram_user(chat_id: str, username: str, first_name: str, last_name: str, is_admin: bool = False, game_config: dict = None) -> TelegramUser:
    """Creates or updates a Telegram user's information."""
    session = SessionTelegramUsers()
    try:
        user = session.query(TelegramUser).filter_by(chat_id=chat_id).first()
        if user:
            user.username = username
            user.first_name = first_name
            user.last_name = last_name
            user.is_admin = is_admin # Admin status is set from config.py
            if game_config:
                user.game_config_json = json.dumps(game_config, ensure_ascii=False)
        else:
            user = TelegramUser(
                chat_id=chat_id,
                username=username,
                first_name=first_name,
                last_name=last_name,
                is_admin=is_admin,
                game_config_json=json.dumps(game_config, ensure_ascii=False) if game_config else None
            )
            session.add(user)
        session.commit()
        return user
    except Exception as e:
        session.rollback()
        console.print(f"[red]Error creating/updating Telegram user {chat_id}: {e}[/red]")
        return None
    finally:
        session.close()

def get_all_telegram_users() -> list[TelegramUser]:
    """Retrieves all registered Telegram users."""
    session = SessionTelegramUsers()
    try:
        return session.query(TelegramUser).all()
    finally:
        session.close()

def get_user_game_config(chat_id: str) -> dict:
    """Retrieves a user's game configuration."""
    user = get_telegram_user(chat_id)
    if user and user.game_config_json:
        return json.loads(user.game_config_json)
    return None

def update_user_game_config(chat_id: str, new_config: dict) -> bool:
    """Updates specific fields in a user's game configuration."""
    session = SessionTelegramUsers()
    try:
        user = session.query(TelegramUser).filter_by(chat_id=chat_id).first()
        if user:
            current_config = json.loads(user.game_config_json) if user.game_config_json else {}
            current_config.update(new_config)
            user.game_config_json = json.dumps(current_config, ensure_ascii=False)
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        console.print(f"[red]Error updating user game config for {chat_id}: {e}[/red]")
        return False
    finally:
        session.close()

def set_user_bot_running_status(chat_id: str, status: bool) -> bool:
    """Sets the bot running status for a specific user."""
    session = SessionTelegramUsers()
    try:
        user = session.query(TelegramUser).filter_by(chat_id=chat_id).first()
        if user:
            user.is_bot_running = status
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        console.print(f"[red]Error setting bot running status for {chat_id}: {e}[/red]")
        return False
    finally:
        session.close()