package com.karmacrash;

import meteordevelopment.meteorclient.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class Overflow1Addon extends MeteorAddon {
    public static final Category CATEGORY = new Category("Crash");

    @Override
    public void onInitialize() {
        Modules.get().add(new Overflow1Module());
    }

    @Override
    public String getPackage() {
        return "com.karmacrash";
    }
}